<?php
class cbDefault extends xPDOSimpleObject {}
