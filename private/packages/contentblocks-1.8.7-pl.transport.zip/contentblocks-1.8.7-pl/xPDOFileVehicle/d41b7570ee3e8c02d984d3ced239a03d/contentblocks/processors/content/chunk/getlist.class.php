<?php

/**
 * Class ContentBlocksChunkGetListProcessor
 */
class ContentBlocksChunkGetListProcessor extends modObjectGetListProcessor {
    public $classKey = 'modChunk';
    public $languageTopics = array('chunk','category');
}
return 'ContentBlocksChunkGetListProcessor';
